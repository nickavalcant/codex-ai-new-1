import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const EXTRACTION_PROMPT = `Você é um especialista em extrair dados de holerites brasileiros.
Analise o conteúdo do holerite fornecido e extraia TODOS os dados em formato JSON estruturado.

REGRAS IMPORTANTES:
1. Extraia EXATAMENTE os valores que aparecem no documento
2. Para valores monetários brasileiros, converta para número decimal (ex: "1.500,00" → 1500.00, "R$ 2.345,67" → 2345.67)
3. Se um campo não for encontrado no documento, use null
4. Seja flexível com variações de nomenclatura:
   - Nome: "Nome", "Funcionário", "Colaborador", "Empregado"
   - Cargo: "Cargo", "Função", "Ocupação", "Atividade"
   - Salário Base: "Salário Base", "Vencimento Base", "Salário", "Ordenado"
   - Líquido: "Líquido", "Valor Líquido", "Total Líquido", "A Receber"
   - Proventos: "Proventos", "Vencimentos", "Créditos", "Rendimentos"
   - Descontos: "Descontos", "Débitos", "Deduções"

5. Identifique TODOS os valores de proventos e descontos listados
6. Some os valores quando necessário para calcular totais

Retorne APENAS um JSON válido (sem markdown, sem explicações) com esta estrutura exata:
{
  "employee": "nome completo do funcionário",
  "cargo": "cargo ou função",
  "departamento": "departamento ou setor",
  "banco": "nome do banco",
  "agencia": "número da agência",
  "conta": "número da conta",
  "period": "período de referência (MM/AAAA ou similar)",
  "dataEmissao": "data de emissão do documento",
  "salarioBase": 0.00,
  "horasExtras": 0.00,
  "adicionais": 0.00,
  "bonus": 0.00,
  "comissoes": 0.00,
  "totalProventos": 0.00,
  "inss": 0.00,
  "irrf": 0.00,
  "faltas": 0.00,
  "atrasos": 0.00,
  "beneficios": 0.00,
  "impostos": 0.00,
  "totalDescontos": 0.00,
  "salarioLiquido": 0.00
}

CONTEÚDO DO HOLERITE:
`;

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const requestBody = await req.json();
    const { pdfBase64, fileName } = requestBody;
    
    console.log('=== NOVA REQUISIÇÃO DE PROCESSAMENTO ===');
    console.log('Arquivo:', fileName);
    console.log('Tamanho base64:', pdfBase64?.length || 0);

    if (!pdfBase64) {
      console.error('PDF base64 não fornecido');
      return new Response(
        JSON.stringify({ error: 'PDF base64 é obrigatório' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      console.error('LOVABLE_API_KEY não configurada');
      return new Response(
        JSON.stringify({ error: 'Chave API não configurada' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Send PDF as base64 image to AI with vision capability
    console.log('Enviando PDF para análise com IA...');
    
    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: EXTRACTION_PROMPT
              },
              {
                type: 'image_url',
                image_url: {
                  url: `data:application/pdf;base64,${pdfBase64}`
                }
              }
            ]
          }
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Erro na API de IA:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Limite de requisições excedido. Aguarde alguns segundos.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Créditos insuficientes. Adicione créditos à sua conta.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      return new Response(
        JSON.stringify({ error: 'Erro ao processar PDF com IA' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    
    console.log('Resposta da IA recebida');
    console.log('Conteúdo bruto:', content?.substring(0, 500));

    if (!content) {
      console.error('Resposta da IA vazia');
      return new Response(
        JSON.stringify({ error: 'Resposta da IA vazia' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Extract JSON from response (handle markdown code blocks if present)
    let jsonStr = content.trim();
    
    // Remove markdown code blocks if present
    const jsonMatch = jsonStr.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (jsonMatch) {
      jsonStr = jsonMatch[1].trim();
    }
    
    // Try to find JSON object in the response
    const jsonStartIndex = jsonStr.indexOf('{');
    const jsonEndIndex = jsonStr.lastIndexOf('}');
    if (jsonStartIndex !== -1 && jsonEndIndex !== -1) {
      jsonStr = jsonStr.substring(jsonStartIndex, jsonEndIndex + 1);
    }

    let extractedData;
    try {
      extractedData = JSON.parse(jsonStr);
      console.log('Dados extraídos com sucesso:', JSON.stringify(extractedData, null, 2));
    } catch (parseError) {
      console.error('Erro ao parsear JSON:', parseError);
      console.error('JSON string:', jsonStr);
      return new Response(
        JSON.stringify({ error: 'Erro ao interpretar resposta da IA' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('=== PROCESSAMENTO CONCLUÍDO ===');

    return new Response(
      JSON.stringify({ 
        success: true,
        data: extractedData,
        fileName: fileName 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Erro na função:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Erro desconhecido' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
