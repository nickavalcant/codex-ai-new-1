import { FileText, Download, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";

const recentPayslips = [
  { id: 1, employee: "Pedro Oliveira", role: "Analista", period: "01/2024", salary: 4350.00, status: "Emitido" },
  { id: 2, employee: "Maria Santos", role: "Desenvolvedora", period: "01/2024", salary: 6200.00, status: "Emitido" },
  { id: 3, employee: "João Silva", role: "Gerente", period: "01/2024", salary: 8500.00, status: "Pendente" },
  { id: 4, employee: "Ana Costa", role: "Designer", period: "01/2024", salary: 5100.00, status: "Emitido" },
  { id: 5, employee: "Carlos Lima", role: "Contador", period: "01/2024", salary: 5800.00, status: "Emitido" },
];

export function RecentPayslips() {
  return (
    <div className="glass-card rounded-xl p-6 animate-slide-up opacity-0" style={{ animationDelay: '500ms', animationFillMode: 'forwards' }}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Holerites Recentes</h3>
          <p className="text-sm text-muted-foreground">Últimos documentos gerados</p>
        </div>
        <Button variant="ghost" size="sm">
          Ver todos
        </Button>
      </div>
      
      <div className="space-y-3">
        {recentPayslips.map((payslip) => (
          <div 
            key={payslip.id}
            className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className="p-2 rounded-lg bg-primary/10">
                <FileText className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground">{payslip.employee}</p>
                <p className="text-sm text-muted-foreground">{payslip.role} • {payslip.period}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="font-mono font-semibold text-foreground">
                  R$ {payslip.salary.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  payslip.status === "Emitido" 
                    ? "bg-success/20 text-success" 
                    : "bg-warning/20 text-warning"
                }`}>
                  {payslip.status}
                </span>
              </div>
              
              <div className="flex items-center gap-1">
                <button className="p-2 rounded-lg hover:bg-secondary transition-colors">
                  <Eye className="w-4 h-4 text-muted-foreground" />
                </button>
                <button className="p-2 rounded-lg hover:bg-secondary transition-colors">
                  <Download className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
