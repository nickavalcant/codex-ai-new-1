import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const data = [
  { name: 'TI', value: 45, color: 'hsl(199 89% 48%)' },
  { name: 'RH', value: 20, color: 'hsl(160 84% 39%)' },
  { name: 'Financeiro', value: 18, color: 'hsl(38 92% 50%)' },
  { name: 'Comercial', value: 25, color: 'hsl(280 70% 50%)' },
  { name: 'Operações', value: 35, color: 'hsl(340 75% 55%)' },
];

export function DepartmentChart() {
  return (
    <div className="glass-card rounded-xl p-6 animate-slide-up opacity-0" style={{ animationDelay: '400ms', animationFillMode: 'forwards' }}>
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground">Colaboradores por Departamento</h3>
        <p className="text-sm text-muted-foreground">Distribuição atual</p>
      </div>
      
      <div className="flex items-center gap-8">
        <div className="h-[200px] w-[200px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={4}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(222 47% 10%)', 
                  border: '1px solid hsl(217 33% 17%)',
                  borderRadius: '8px',
                  color: 'hsl(210 40% 98%)'
                }}
                formatter={(value: number) => [`${value} colaboradores`, '']}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        
        <div className="flex-1 space-y-3">
          {data.map((item) => (
            <div key={item.name} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-sm text-muted-foreground">{item.name}</span>
              </div>
              <span className="text-sm font-medium text-foreground">{item.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
