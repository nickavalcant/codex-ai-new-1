import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface Employee {
  id: number;
  name: string;
  cpf: string;
  cargo: string;
  departamento: string;
  banco: string;
  agencia: string;
  conta: string;
  salario: number;
}

interface EmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  employee?: Employee | null;
}

export function EmployeeModal({ isOpen, onClose, employee }: EmployeeModalProps) {
  const isEditing = !!employee;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-foreground">
            {isEditing ? "Editar Colaborador" : "Novo Colaborador"}
          </DialogTitle>
        </DialogHeader>

        <form className="space-y-6 mt-4">
          {/* Dados Pessoais */}
          <div>
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
              Dados Pessoais
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome Completo</Label>
                <Input 
                  id="name" 
                  placeholder="Nome do colaborador"
                  defaultValue={employee?.name}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cpf">CPF</Label>
                <Input 
                  id="cpf" 
                  placeholder="000.000.000-00"
                  defaultValue={employee?.cpf}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cargo">Cargo</Label>
                <Input 
                  id="cargo" 
                  placeholder="Cargo do colaborador"
                  defaultValue={employee?.cargo}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="departamento">Departamento</Label>
                <Input 
                  id="departamento" 
                  placeholder="Departamento"
                  defaultValue={employee?.departamento}
                />
              </div>
            </div>
          </div>

          {/* Dados Bancários */}
          <div>
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
              Dados Bancários
            </h3>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="banco">Banco</Label>
                <Input 
                  id="banco" 
                  placeholder="Nome do banco"
                  defaultValue={employee?.banco}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="agencia">Agência</Label>
                <Input 
                  id="agencia" 
                  placeholder="0000"
                  defaultValue={employee?.agencia}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="conta">Conta</Label>
                <Input 
                  id="conta" 
                  placeholder="00000-0"
                  defaultValue={employee?.conta}
                />
              </div>
            </div>
          </div>

          {/* Salário */}
          <div>
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
              Remuneração
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="salario">Salário Base</Label>
                <Input 
                  id="salario" 
                  placeholder="R$ 0,00"
                  defaultValue={employee?.salario ? `R$ ${employee.salario.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : ''}
                />
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-border">
            <Button variant="outline" type="button" onClick={onClose}>
              Cancelar
            </Button>
            <Button variant="glow" type="submit">
              {isEditing ? "Salvar Alterações" : "Criar Colaborador"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
