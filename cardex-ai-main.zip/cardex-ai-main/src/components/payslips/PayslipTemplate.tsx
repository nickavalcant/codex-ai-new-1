import { forwardRef } from 'react';

interface PayslipTemplateProps {
  companyName?: string;
  companyAddress?: string;
  companyCNPJ?: string;
  period: string;
  employeeNumber?: string;
  employeeName: string;
  admissionDate?: string;
  cbo?: string;
  pisCN?: string;
  role: string;
  bank?: string;
  agency?: string;
  account?: string;
  earnings: Array<{
    code: string;
    description: string;
    reference?: string;
    value: number;
  }>;
  deductions: Array<{
    code: string;
    description: string;
    reference?: string;
    value: number;
  }>;
  totalEarnings: number;
  totalDeductions: number;
  netSalary: number;
  baseSalary?: number;
  inssBase?: number;
  fgtsBase?: number;
  fgtsValue?: number;
  irrfBase?: number;
}

const PayslipTemplate = forwardRef<HTMLDivElement, PayslipTemplateProps>(({
  companyName = 'Empresa',
  companyAddress,
  companyCNPJ,
  period,
  employeeNumber,
  employeeName,
  admissionDate,
  cbo,
  pisCN,
  role,
  bank,
  agency,
  account,
  earnings,
  deductions,
  totalEarnings,
  totalDeductions,
  netSalary,
  baseSalary,
  inssBase,
  fgtsBase,
  fgtsValue,
  irrfBase,
}, ref) => {
  const formatCurrency = (value: number) => {
    return value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  return (
    <div ref={ref} className="bg-white text-gray-900 p-6 font-sans text-sm">
      {/* Header */}
      <div className="border-2 border-gray-800 p-4 mb-4">
        <h1 className="text-center text-lg font-bold mb-2">
          Demonstrativo de Pagamento de Salário
        </h1>
        <p className="text-center text-base font-medium">{companyName}</p>
        {companyAddress && (
          <p className="text-center text-xs text-gray-600">{companyAddress}</p>
        )}
        <div className="flex justify-between mt-2 text-xs">
          <span>Período: <strong>{period}</strong></span>
          {companyCNPJ && <span>CNPJ: {companyCNPJ}</span>}
        </div>
      </div>

      {/* Employee Info */}
      <div className="mb-4">
        <div className="bg-gray-200 px-3 py-1 font-bold text-sm mb-2">
          Funcionário
        </div>
        <table className="w-full border-collapse border border-gray-400 text-xs">
          <thead>
            <tr className="bg-gray-500 text-white">
              <th className="border border-gray-400 px-2 py-1 text-left">Nro</th>
              <th className="border border-gray-400 px-2 py-1 text-left">Nome</th>
              <th className="border border-gray-400 px-2 py-1 text-left">Admissão</th>
              <th className="border border-gray-400 px-2 py-1 text-left">CBO</th>
              <th className="border border-gray-400 px-2 py-1 text-left">PIS/CN</th>
              <th className="border border-gray-400 px-2 py-1 text-left">Função</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border border-gray-400 px-2 py-1">{employeeNumber || '-'}</td>
              <td className="border border-gray-400 px-2 py-1 font-medium">{employeeName}</td>
              <td className="border border-gray-400 px-2 py-1">{admissionDate || '-'}</td>
              <td className="border border-gray-400 px-2 py-1">{cbo || '-'}</td>
              <td className="border border-gray-400 px-2 py-1">{pisCN || '-'}</td>
              <td className="border border-gray-400 px-2 py-1">{role}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Bank Info */}
      {(bank || agency || account) && (
        <div className="mb-4">
          <div className="bg-gray-100 px-3 py-1 font-bold text-sm mb-2">
            Dados Bancários
          </div>
          <table className="w-full border-collapse border border-gray-400 text-xs">
            <thead>
              <tr className="bg-gray-500 text-white">
                <th className="border border-gray-400 px-2 py-1 text-left">Banco</th>
                <th className="border border-gray-400 px-2 py-1 text-left">Agência</th>
                <th className="border border-gray-400 px-2 py-1 text-left">Conta</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-400 px-2 py-1">{bank || '-'}</td>
                <td className="border border-gray-400 px-2 py-1">{agency || '-'}</td>
                <td className="border border-gray-400 px-2 py-1">{account || '-'}</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {/* Earnings and Deductions */}
      <div className="mb-4">
        <div className="bg-gray-200 px-3 py-1 font-bold text-sm mb-2">
          Vencimentos e Descontos
        </div>
        <table className="w-full border-collapse border border-gray-400 text-xs">
          <thead>
            <tr className="bg-gray-500 text-white">
              <th className="border border-gray-400 px-2 py-1 text-left w-12">Cód</th>
              <th className="border border-gray-400 px-2 py-1 text-left">Descrição</th>
              <th className="border border-gray-400 px-2 py-1 text-left w-16">Ref.</th>
              <th className="border border-gray-400 px-2 py-1 text-right w-24">Vencimentos</th>
              <th className="border border-gray-400 px-2 py-1 text-right w-24">Descontos</th>
            </tr>
          </thead>
          <tbody>
            {earnings.map((earning, index) => (
              <tr key={`earning-${index}`}>
                <td className="border border-gray-400 px-2 py-1">{earning.code}</td>
                <td className="border border-gray-400 px-2 py-1">{earning.description}</td>
                <td className="border border-gray-400 px-2 py-1">{earning.reference || ''}</td>
                <td className="border border-gray-400 px-2 py-1 text-right font-mono">
                  {formatCurrency(earning.value)}
                </td>
                <td className="border border-gray-400 px-2 py-1"></td>
              </tr>
            ))}
            {deductions.map((deduction, index) => (
              <tr key={`deduction-${index}`}>
                <td className="border border-gray-400 px-2 py-1">{deduction.code}</td>
                <td className="border border-gray-400 px-2 py-1">{deduction.description}</td>
                <td className="border border-gray-400 px-2 py-1">{deduction.reference || ''}</td>
                <td className="border border-gray-400 px-2 py-1"></td>
                <td className="border border-gray-400 px-2 py-1 text-right font-mono">
                  {formatCurrency(deduction.value)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Totals */}
      <div className="mb-4">
        <div className="bg-gray-200 px-3 py-1 font-bold text-sm mb-2">
          Totais
        </div>
        <table className="w-full border-collapse border border-gray-400 text-xs">
          <tbody>
            <tr>
              <td className="border border-gray-400 px-2 py-1 font-bold bg-gray-100">Total Vencimentos</td>
              <td className="border border-gray-400 px-2 py-1 text-right font-mono text-green-700 font-bold">
                {formatCurrency(totalEarnings)}
              </td>
              <td className="border border-gray-400 px-2 py-1 font-bold bg-gray-100">Total Descontos</td>
              <td className="border border-gray-400 px-2 py-1 text-right font-mono text-red-700 font-bold">
                {formatCurrency(totalDeductions)}
              </td>
            </tr>
            <tr className="bg-gray-800 text-white">
              <td colSpan={2} className="border border-gray-400 px-2 py-2 font-bold text-base">
                Valor Líquido
              </td>
              <td colSpan={2} className="border border-gray-400 px-2 py-2 text-right font-mono font-bold text-lg">
                R$ {formatCurrency(netSalary)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Fiscal Info */}
      {(baseSalary || inssBase || fgtsBase) && (
        <div className="mb-4">
          <div className="bg-gray-100 px-3 py-1 font-bold text-sm mb-2">
            Informações Fiscais
          </div>
          <table className="w-full border-collapse border border-gray-400 text-xs">
            <thead>
              <tr className="bg-gray-500 text-white">
                <th className="border border-gray-400 px-1 py-1 text-center">Sal. Base</th>
                <th className="border border-gray-400 px-1 py-1 text-center">Contr. INSS</th>
                <th className="border border-gray-400 px-1 py-1 text-center">Base FGTS</th>
                <th className="border border-gray-400 px-1 py-1 text-center">Valor FGTS</th>
                <th className="border border-gray-400 px-1 py-1 text-center">Base IRRF</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-400 px-1 py-1 text-center font-mono">
                  {baseSalary ? formatCurrency(baseSalary) : '-'}
                </td>
                <td className="border border-gray-400 px-1 py-1 text-center font-mono">
                  {inssBase ? formatCurrency(inssBase) : '-'}
                </td>
                <td className="border border-gray-400 px-1 py-1 text-center font-mono">
                  {fgtsBase ? formatCurrency(fgtsBase) : '-'}
                </td>
                <td className="border border-gray-400 px-1 py-1 text-center font-mono">
                  {fgtsValue ? formatCurrency(fgtsValue) : '-'}
                </td>
                <td className="border border-gray-400 px-1 py-1 text-center font-mono">
                  {irrfBase ? formatCurrency(irrfBase) : '-'}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {/* Signature Section */}
      <div className="border border-gray-400 p-4 bg-gray-50">
        <p className="font-bold text-sm mb-2">Declaração</p>
        <p className="text-xs mb-4">
          DECLARO TER RECEBIDO A IMPORTÂNCIA LÍQUIDA DISCRIMINADA NESTE RECIBO
        </p>
        <div className="flex justify-between items-end mt-4">
          <span className="text-xs">Data: ____/____/____</span>
          <span className="text-xs">Assinatura: _________________________________________</span>
        </div>
      </div>
    </div>
  );
});

PayslipTemplate.displayName = 'PayslipTemplate';

export default PayslipTemplate;
