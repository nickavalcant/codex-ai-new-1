import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Save, FileDown, Copy, Trash2, Calculator } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

interface PayslipData {
  employee: string;
  cargo: string;
  cpf: string;
  banco: string;
  agencia: string;
  conta: string;
  period: string;
  dataEmissao: string;
  salarioBase: number;
  horasExtras: number;
  adicionais: number;
  bonus: number;
  faltas: number;
  beneficios: number;
  impostos: number;
}

const defaultPayslip: PayslipData = {
  employee: "Pedro Oliveira",
  cargo: "Analista",
  cpf: "123.456.789-00",
  banco: "Itaú",
  agencia: "5555",
  conta: "11111-2",
  period: "01/2024",
  dataEmissao: "01/12/2025",
  salarioBase: 4000.00,
  horasExtras: 500.00,
  adicionais: 300.00,
  bonus: 400.00,
  faltas: 0,
  beneficios: 350.00,
  impostos: 500.00,
};

export default function PayslipEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = id === "new";

  const [payslip, setPayslip] = useState<PayslipData>(defaultPayslip);

  const totalProventos = payslip.salarioBase + payslip.horasExtras + payslip.adicionais + payslip.bonus;
  const totalDescontos = payslip.faltas + payslip.beneficios + payslip.impostos;
  const salarioLiquido = totalProventos - totalDescontos;

  const handleChange = (field: keyof PayslipData, value: string | number) => {
    setPayslip(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    toast({
      title: "Holerite salvo!",
      description: "As alterações foram salvas com sucesso.",
    });
  };

  const handleGeneratePDF = () => {
    toast({
      title: "PDF gerado!",
      description: "O holerite foi exportado em PDF.",
    });
  };

  return (
    <MainLayout>
      {/* Header */}
      <div className="h-16 border-b border-border bg-background/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="h-full px-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-semibold text-foreground">
                {isNew ? "Novo Holerite" : `Holerite - ${payslip.employee}`}
              </h1>
              <p className="text-sm text-muted-foreground">
                {isNew ? "Crie um novo holerite" : `Período: ${payslip.period}`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={() => {}}>
              <Copy className="w-4 h-4 mr-2" />
              Duplicar
            </Button>
            <Button variant="outline" onClick={handleGeneratePDF}>
              <FileDown className="w-4 h-4 mr-2" />
              Gerar PDF
            </Button>
            <Button variant="glow" onClick={handleSave}>
              <Save className="w-4 h-4 mr-2" />
              Salvar
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Employee Info */}
          <div className="glass-card rounded-xl p-6 animate-slide-up opacity-0" style={{ animationDelay: '0ms', animationFillMode: 'forwards' }}>
            <h2 className="text-lg font-semibold text-foreground mb-4">Dados do Colaborador</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Nome</Label>
                <Input 
                  value={payslip.employee} 
                  onChange={(e) => handleChange('employee', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Cargo</Label>
                <Input 
                  value={payslip.cargo} 
                  onChange={(e) => handleChange('cargo', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>CPF</Label>
                <Input 
                  value={payslip.cpf} 
                  onChange={(e) => handleChange('cpf', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Banco</Label>
                <Input 
                  value={payslip.banco} 
                  onChange={(e) => handleChange('banco', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Agência</Label>
                <Input 
                  value={payslip.agencia} 
                  onChange={(e) => handleChange('agencia', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Conta</Label>
                <Input 
                  value={payslip.conta} 
                  onChange={(e) => handleChange('conta', e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Period Info */}
          <div className="glass-card rounded-xl p-6 animate-slide-up opacity-0" style={{ animationDelay: '100ms', animationFillMode: 'forwards' }}>
            <h2 className="text-lg font-semibold text-foreground mb-4">Período</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Período de Referência</Label>
                <Input 
                  value={payslip.period} 
                  onChange={(e) => handleChange('period', e.target.value)}
                  placeholder="MM/AAAA"
                />
              </div>
              <div className="space-y-2">
                <Label>Data de Emissão</Label>
                <Input 
                  value={payslip.dataEmissao} 
                  onChange={(e) => handleChange('dataEmissao', e.target.value)}
                  placeholder="DD/MM/AAAA"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Proventos */}
            <div className="glass-card rounded-xl p-6 animate-slide-up opacity-0" style={{ animationDelay: '200ms', animationFillMode: 'forwards' }}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-foreground">Proventos</h2>
                <span className="text-xs px-2 py-1 rounded-full bg-success/20 text-success">
                  Créditos
                </span>
              </div>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Salário Base</Label>
                  <Input 
                    type="number"
                    value={payslip.salarioBase} 
                    onChange={(e) => handleChange('salarioBase', parseFloat(e.target.value) || 0)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Horas Extras</Label>
                  <Input 
                    type="number"
                    value={payslip.horasExtras} 
                    onChange={(e) => handleChange('horasExtras', parseFloat(e.target.value) || 0)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Adicionais</Label>
                  <Input 
                    type="number"
                    value={payslip.adicionais} 
                    onChange={(e) => handleChange('adicionais', parseFloat(e.target.value) || 0)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Bônus</Label>
                  <Input 
                    type="number"
                    value={payslip.bonus} 
                    onChange={(e) => handleChange('bonus', parseFloat(e.target.value) || 0)}
                  />
                </div>
                <div className="pt-4 border-t border-border flex items-center justify-between">
                  <span className="font-medium text-foreground">Total Proventos</span>
                  <span className="font-mono font-bold text-xl text-success">
                    R$ {totalProventos.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>

            {/* Descontos */}
            <div className="glass-card rounded-xl p-6 animate-slide-up opacity-0" style={{ animationDelay: '300ms', animationFillMode: 'forwards' }}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-foreground">Descontos</h2>
                <span className="text-xs px-2 py-1 rounded-full bg-destructive/20 text-destructive">
                  Débitos
                </span>
              </div>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Faltas</Label>
                  <Input 
                    type="number"
                    value={payslip.faltas} 
                    onChange={(e) => handleChange('faltas', parseFloat(e.target.value) || 0)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Benefícios</Label>
                  <Input 
                    type="number"
                    value={payslip.beneficios} 
                    onChange={(e) => handleChange('beneficios', parseFloat(e.target.value) || 0)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Impostos (INSS/IRRF)</Label>
                  <Input 
                    type="number"
                    value={payslip.impostos} 
                    onChange={(e) => handleChange('impostos', parseFloat(e.target.value) || 0)}
                  />
                </div>
                <div className="pt-4 mt-8 border-t border-border flex items-center justify-between">
                  <span className="font-medium text-foreground">Total Descontos</span>
                  <span className="font-mono font-bold text-xl text-destructive">
                    R$ {totalDescontos.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Salary Summary */}
          <div className="glass-card rounded-xl p-8 animate-slide-up opacity-0 gradient-border" style={{ animationDelay: '400ms', animationFillMode: 'forwards' }}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-4 rounded-xl bg-gradient-to-br from-primary to-accent">
                  <Calculator className="w-8 h-8 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-muted-foreground">Salário Líquido</p>
                  <p className="text-sm text-muted-foreground">
                    {payslip.employee} • {payslip.period}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-mono font-bold text-4xl gradient-text">
                  R$ {salarioLiquido.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  Proventos: R$ {totalProventos.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} - 
                  Descontos: R$ {totalDescontos.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
