import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Filter, Eye, Download, Edit, Copy, Trash2, FileText, Calendar } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Header } from "@/components/layout/Header";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { generatePayslipPDF, convertToPayslipPDFData } from "@/lib/generatePayslipPDF";
import PayslipTemplate from "@/components/payslips/PayslipTemplate";

interface Payslip {
  id: number;
  employee: string;
  cargo: string;
  period: string;
  proventos: number;
  descontos: number;
  liquido: number;
  status: string;
  origem: string;
  banco?: string;
  agencia?: string;
  conta?: string;
  salarioBase?: number;
  horasExtras?: number;
  inss?: number;
  irrf?: number;
}

const payslips: Payslip[] = [
  { id: 1, employee: "Pedro Oliveira", cargo: "Analista", period: "01/2024", proventos: 5200.00, descontos: 850.00, liquido: 4350.00, status: "Emitido", origem: "Manual", banco: "Itaú", agencia: "5555", conta: "11111-2", salarioBase: 4000, horasExtras: 500, inss: 440, irrf: 410 },
  { id: 2, employee: "Maria Santos", cargo: "Desenvolvedora", period: "01/2024", proventos: 7500.00, descontos: 1300.00, liquido: 6200.00, status: "Emitido", origem: "Importado", banco: "Bradesco", agencia: "1234", conta: "22222-3", salarioBase: 6500, horasExtras: 1000, inss: 751, irrf: 549 },
  { id: 3, employee: "João Silva", cargo: "Gerente", period: "01/2024", proventos: 10500.00, descontos: 2000.00, liquido: 8500.00, status: "Pendente", origem: "Manual", banco: "Santander", agencia: "0001", conta: "33333-4", salarioBase: 9000, horasExtras: 1500, inss: 877, irrf: 1123 },
  { id: 4, employee: "Ana Costa", cargo: "Designer", period: "01/2024", proventos: 6200.00, descontos: 1100.00, liquido: 5100.00, status: "Emitido", origem: "Importado", banco: "Banco do Brasil", agencia: "4567", conta: "44444-5", salarioBase: 5500, horasExtras: 700, inss: 620, irrf: 480 },
  { id: 5, employee: "Carlos Lima", cargo: "Contador", period: "01/2024", proventos: 7000.00, descontos: 1200.00, liquido: 5800.00, status: "Emitido", origem: "Manual", banco: "Caixa", agencia: "7890", conta: "55555-6", salarioBase: 6200, horasExtras: 800, inss: 700, irrf: 500 },
  { id: 6, employee: "Fernanda Rocha", cargo: "Analista RH", period: "12/2023", proventos: 5800.00, descontos: 1000.00, liquido: 4800.00, status: "Emitido", origem: "Importado", banco: "Nubank", agencia: "0001", conta: "66666-7", salarioBase: 5000, horasExtras: 800, inss: 580, irrf: 420 },
];

export default function Payslips() {
  const navigate = useNavigate();
  const [selectedPayslip, setSelectedPayslip] = useState<Payslip | null>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);

  const formatCurrency = (value: number) => {
    return `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  };

  const handleView = (payslip: Payslip, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedPayslip(payslip);
    setIsViewModalOpen(true);
  };

  const handleDownloadPDF = (payslip: Payslip, e: React.MouseEvent) => {
    e.stopPropagation();
    
    try {
      // Convert payslip data to PDF format
      const pdfData = convertToPayslipPDFData({
        employee: payslip.employee,
        cargo: payslip.cargo,
        period: payslip.period,
        proventos: payslip.proventos,
        descontos: payslip.descontos,
        liquido: payslip.liquido,
        banco: payslip.banco,
        agencia: payslip.agencia,
        conta: payslip.conta,
        salarioBase: payslip.salarioBase,
        horasExtras: payslip.horasExtras,
        inss: payslip.inss,
        irrf: payslip.irrf,
      }, 'Sua Empresa Ltda');

      // Generate and download PDF
      generatePayslipPDF(pdfData);

      toast({
        title: "PDF gerado com sucesso",
        description: `Holerite de ${payslip.employee} baixado.`,
      });
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      toast({
        title: "Erro ao gerar PDF",
        description: "Não foi possível gerar o arquivo PDF.",
        variant: "destructive",
      });
    }
  };

  const handleCopy = (payslip: Payslip, e: React.MouseEvent) => {
    e.stopPropagation();
    
    const textToCopy = `
Holerite - ${payslip.employee}
Período: ${payslip.period}
Cargo: ${payslip.cargo}
Proventos: ${formatCurrency(payslip.proventos)}
Descontos: ${formatCurrency(payslip.descontos)}
Líquido: ${formatCurrency(payslip.liquido)}
Status: ${payslip.status}
    `.trim();

    navigator.clipboard.writeText(textToCopy).then(() => {
      toast({
        title: "Copiado!",
        description: "Dados do holerite copiados para a área de transferência.",
      });
    }).catch(() => {
      toast({
        title: "Erro ao copiar",
        description: "Não foi possível copiar os dados.",
        variant: "destructive",
      });
    });
  };

  return (
    <MainLayout>
      <Header 
        title="Holerites" 
        subtitle="Visualize e gerencie todos os holerites"
        action={{ label: "Novo Holerite", onClick: () => navigate('/payslips/new') }}
      />
      
      <div className="p-6 space-y-6">
        {/* Filters */}
        <div className="glass-card rounded-xl p-4 animate-fade-in">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="relative flex-1 min-w-[250px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="Buscar por colaborador..." className="pl-10" />
            </div>
            <Select defaultValue="all">
              <SelectTrigger className="w-[180px]">
                <Calendar className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os períodos</SelectItem>
                <SelectItem value="01-2024">Janeiro 2024</SelectItem>
                <SelectItem value="12-2023">Dezembro 2023</SelectItem>
                <SelectItem value="11-2023">Novembro 2023</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="all">
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="emitido">Emitido</SelectItem>
                <SelectItem value="pendente">Pendente</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Mais Filtros
            </Button>
          </div>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {payslips.map((payslip, index) => (
            <div 
              key={payslip.id}
              className="glass-card-hover rounded-xl p-6 cursor-pointer animate-slide-up opacity-0"
              style={{ animationDelay: `${index * 50}ms`, animationFillMode: 'forwards' }}
              onClick={() => navigate(`/payslips/${payslip.id}`)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/50 to-accent/50 flex items-center justify-center">
                    <FileText className="w-6 h-6 text-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{payslip.employee}</h3>
                    <p className="text-sm text-muted-foreground">{payslip.cargo}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    payslip.status === "Emitido" 
                      ? "bg-success/20 text-success" 
                      : "bg-warning/20 text-warning"
                  }`}>
                    {payslip.status}
                  </span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    payslip.origem === "Importado" 
                      ? "bg-info/20 text-info" 
                      : "bg-secondary text-muted-foreground"
                  }`}>
                    {payslip.origem}
                  </span>
                </div>
              </div>

              <div className="space-y-3 pt-4 border-t border-border">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Período</span>
                  <span className="font-medium text-foreground">{payslip.period}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Proventos</span>
                  <span className="font-mono text-success">
                    + {formatCurrency(payslip.proventos)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Descontos</span>
                  <span className="font-mono text-destructive">
                    - {formatCurrency(payslip.descontos)}
                  </span>
                </div>
                <div className="flex items-center justify-between pt-3 border-t border-border">
                  <span className="font-medium text-foreground">Líquido</span>
                  <span className="font-mono font-bold text-lg text-foreground">
                    {formatCurrency(payslip.liquido)}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 mt-4 pt-4 border-t border-border">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="flex-1" 
                  onClick={(e) => handleView(payslip, e)}
                >
                  <Eye className="w-4 h-4 mr-1" />
                  Ver
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="flex-1" 
                  onClick={(e) => handleDownloadPDF(payslip, e)}
                >
                  <Download className="w-4 h-4 mr-1" />
                  PDF
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={(e) => handleCopy(payslip, e)}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Mostrando 1-6 de 286 holerites
          </p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled>Anterior</Button>
            <Button variant="outline" size="sm">Próximo</Button>
          </div>
        </div>
      </div>

      {/* View Modal */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Demonstrativo de Pagamento</DialogTitle>
          </DialogHeader>
          
          {selectedPayslip && (
            <div className="space-y-4">
              {/* Payslip Template Preview */}
              <div className="border rounded-lg overflow-hidden">
                <PayslipTemplate
                  companyName="Sua Empresa Ltda"
                  period={selectedPayslip.period}
                  employeeName={selectedPayslip.employee}
                  role={selectedPayslip.cargo}
                  bank={selectedPayslip.banco}
                  agency={selectedPayslip.agencia}
                  account={selectedPayslip.conta}
                  earnings={[
                    ...(selectedPayslip.salarioBase ? [{ code: '01', description: 'Salário Base', value: selectedPayslip.salarioBase }] : []),
                    ...(selectedPayslip.horasExtras ? [{ code: '02', description: 'Horas Extras', value: selectedPayslip.horasExtras }] : []),
                  ]}
                  deductions={[
                    ...(selectedPayslip.inss ? [{ code: '101', description: 'INSS', reference: '7,5%', value: selectedPayslip.inss }] : []),
                    ...(selectedPayslip.irrf ? [{ code: '102', description: 'IRRF', value: selectedPayslip.irrf }] : []),
                  ]}
                  totalEarnings={selectedPayslip.proventos}
                  totalDeductions={selectedPayslip.descontos}
                  netSalary={selectedPayslip.liquido}
                  baseSalary={selectedPayslip.salarioBase}
                  inssBase={selectedPayslip.proventos}
                  fgtsBase={selectedPayslip.proventos}
                  fgtsValue={selectedPayslip.proventos * 0.08}
                  irrfBase={selectedPayslip.liquido}
                />
              </div>

              {/* Actions */}
              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => setIsViewModalOpen(false)}>
                  Fechar
                </Button>
                <Button onClick={(e) => {
                  handleDownloadPDF(selectedPayslip, e as any);
                  setIsViewModalOpen(false);
                }}>
                  <Download className="w-4 h-4 mr-2" />
                  Baixar PDF
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
