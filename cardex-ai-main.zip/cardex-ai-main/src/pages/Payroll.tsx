import { useState } from "react";
import { Calendar, Play, CheckCircle, Clock, AlertCircle, Download, Users, Eye } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Header } from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface PayrollPeriod {
  id: number;
  period: string;
  status: string;
  employees: number;
  total: number;
  date: string;
  proventos?: number;
  descontos?: number;
}

const payrollPeriods: PayrollPeriod[] = [
  { id: 1, period: "Janeiro 2024", status: "Processado", employees: 143, total: 295000, date: "31/01/2024", proventos: 385000, descontos: 90000 },
  { id: 2, period: "Dezembro 2023", status: "Processado", employees: 140, total: 280000, date: "29/12/2023", proventos: 365000, descontos: 85000 },
  { id: 3, period: "Novembro 2023", status: "Processado", employees: 138, total: 275000, date: "30/11/2023", proventos: 358000, descontos: 83000 },
  { id: 4, period: "Outubro 2023", status: "Processado", employees: 135, total: 262000, date: "31/10/2023", proventos: 342000, descontos: 80000 },
];

export default function Payroll() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedPayroll, setSelectedPayroll] = useState<PayrollPeriod | null>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);

  const formatCurrency = (value: number) => {
    return `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  };

  const handleProcess = async () => {
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsProcessing(false);
    toast({
      title: "Folha processada!",
      description: "A folha de pagamento foi processada com sucesso.",
    });
  };

  const handleViewDetails = (payroll: PayrollPeriod) => {
    setSelectedPayroll(payroll);
    setIsViewModalOpen(true);
  };

  const handleDownload = (payroll: PayrollPeriod) => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      let yPos = 15;

      // Helper for centered text
      const addCenteredText = (text: string, y: number, fontSize: number = 12, style: 'normal' | 'bold' = 'normal') => {
        doc.setFontSize(fontSize);
        doc.setFont('helvetica', style);
        const textWidth = doc.getTextWidth(text);
        doc.text(text, (pageWidth - textWidth) / 2, y);
      };

      // Header
      doc.setDrawColor(0);
      doc.setLineWidth(0.5);
      doc.rect(10, 10, pageWidth - 20, 25);
      
      addCenteredText('Relatório de Folha de Pagamento', 20, 14, 'bold');
      addCenteredText(`Período: ${payroll.period}`, 30, 11);

      yPos = 45;

      // Summary section
      doc.setFillColor(230, 230, 230);
      doc.rect(10, yPos, pageWidth - 20, 8, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.text('Resumo Geral', 15, yPos + 6);
      
      yPos += 12;

      autoTable(doc, {
        startY: yPos,
        margin: { left: 10, right: 10 },
        head: [['Descrição', 'Valor']],
        body: [
          ['Data de Processamento', payroll.date],
          ['Status', payroll.status],
          ['Total de Colaboradores', payroll.employees.toString()],
          ['Total Proventos', formatCurrency(payroll.proventos || 0)],
          ['Total Descontos', formatCurrency(payroll.descontos || 0)],
          ['Total Líquido', formatCurrency(payroll.total)],
        ],
        styles: { fontSize: 9, cellPadding: 3 },
        headStyles: { fillColor: [100, 100, 100], textColor: [255, 255, 255], fontStyle: 'bold' },
        columnStyles: {
          0: { fontStyle: 'bold', cellWidth: 80 },
          1: { halign: 'right' },
        },
        theme: 'grid',
      });

      yPos = (doc as any).lastAutoTable.finalY + 15;

      // Average
      doc.setFillColor(240, 240, 240);
      doc.rect(10, yPos, pageWidth - 20, 20, 'F');
      doc.rect(10, yPos, pageWidth - 20, 20);
      
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.text('Média por Colaborador:', 15, yPos + 8);
      
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text(formatCurrency(payroll.total / payroll.employees), 15, yPos + 16);

      // Footer
      const footerY = doc.internal.pageSize.getHeight() - 10;
      doc.setFontSize(7);
      doc.setTextColor(128);
      addCenteredText(`Documento gerado em ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}`, footerY, 7);

      // Save
      doc.save(`folha_pagamento_${payroll.period.replace(/\s+/g, '_')}.pdf`);

      toast({
        title: "PDF gerado com sucesso",
        description: `Folha de ${payroll.period} baixada.`,
      });
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      toast({
        title: "Erro ao gerar PDF",
        description: "Não foi possível gerar o arquivo PDF.",
        variant: "destructive",
      });
    }
  };

  return (
    <MainLayout>
      <Header 
        title="Folha de Pagamento" 
        subtitle="Processe e gerencie a folha de pagamento"
      />
      
      <div className="p-6 space-y-6">
        {/* Process New Payroll */}
        <div className="glass-card rounded-xl p-6 animate-fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-xl bg-gradient-to-br from-primary to-accent">
                <Calendar className="w-8 h-8 text-primary-foreground" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-foreground">Processar Nova Folha</h2>
                <p className="text-muted-foreground">Calcule automaticamente a folha de pagamento</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Select defaultValue="02-2024">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Selecione o período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="02-2024">Fevereiro 2024</SelectItem>
                  <SelectItem value="01-2024">Janeiro 2024</SelectItem>
                  <SelectItem value="12-2023">Dezembro 2023</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="glow" 
                size="lg"
                onClick={handleProcess}
                disabled={isProcessing}
              >
                {isProcessing ? (
                  <>
                    <Clock className="w-5 h-5 mr-2 animate-spin" />
                    Processando...
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 mr-2" />
                    Processar Folha
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="stat-card animate-slide-up opacity-0" style={{ animationDelay: '100ms', animationFillMode: 'forwards' }}>
            <div className="relative z-10 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-primary/20">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Colaboradores</p>
                <p className="text-2xl font-bold text-foreground">143</p>
              </div>
            </div>
          </div>
          <div className="stat-card animate-slide-up opacity-0" style={{ animationDelay: '150ms', animationFillMode: 'forwards' }}>
            <div className="relative z-10 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-success/20">
                <CheckCircle className="w-6 h-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Proventos</p>
                <p className="text-2xl font-bold text-foreground font-mono">R$ 385k</p>
              </div>
            </div>
          </div>
          <div className="stat-card animate-slide-up opacity-0" style={{ animationDelay: '200ms', animationFillMode: 'forwards' }}>
            <div className="relative z-10 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-destructive/20">
                <AlertCircle className="w-6 h-6 text-destructive" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Descontos</p>
                <p className="text-2xl font-bold text-foreground font-mono">R$ 90k</p>
              </div>
            </div>
          </div>
          <div className="stat-card animate-slide-up opacity-0" style={{ animationDelay: '250ms', animationFillMode: 'forwards' }}>
            <div className="relative z-10 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-accent/20">
                <Download className="w-6 h-6 text-accent" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Líquido Total</p>
                <p className="text-2xl font-bold text-foreground font-mono">R$ 295k</p>
              </div>
            </div>
          </div>
        </div>

        {/* Payroll History */}
        <div className="glass-card rounded-xl overflow-hidden animate-slide-up opacity-0" style={{ animationDelay: '300ms', animationFillMode: 'forwards' }}>
          <div className="p-6 border-b border-border">
            <h2 className="text-lg font-semibold text-foreground">Histórico de Folhas</h2>
            <p className="text-sm text-muted-foreground">Visualize as folhas processadas anteriormente</p>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/30">
                  <th className="text-left py-4 px-6 text-sm font-semibold text-muted-foreground">Período</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-muted-foreground">Status</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-muted-foreground">Colaboradores</th>
                  <th className="text-right py-4 px-6 text-sm font-semibold text-muted-foreground">Total Líquido</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-muted-foreground">Data Processamento</th>
                  <th className="text-center py-4 px-6 text-sm font-semibold text-muted-foreground">Ações</th>
                </tr>
              </thead>
              <tbody>
                {payrollPeriods.map((period) => (
                  <tr key={period.id} className="table-row-hover border-b border-border/50">
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-primary/10">
                          <Calendar className="w-5 h-5 text-primary" />
                        </div>
                        <span className="font-medium text-foreground">{period.period}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className="px-3 py-1 rounded-full bg-success/20 text-success text-sm">
                        {period.status}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-foreground">{period.employees}</td>
                    <td className="py-4 px-6 text-right font-mono font-semibold text-foreground">
                      {formatCurrency(period.total)}
                    </td>
                    <td className="py-4 px-6 text-muted-foreground">{period.date}</td>
                    <td className="py-4 px-6">
                      <div className="flex items-center justify-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleViewDetails(period)}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          Ver Detalhes
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleDownload(period)}
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* View Details Modal */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes da Folha de Pagamento</DialogTitle>
          </DialogHeader>
          
          {selectedPayroll && (
            <div className="space-y-6">
              {/* Period Info */}
              <div className="grid grid-cols-2 gap-4 p-4 rounded-lg bg-secondary/30">
                <div>
                  <p className="text-sm text-muted-foreground">Período</p>
                  <p className="font-semibold text-foreground text-lg">{selectedPayroll.period}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Data de Processamento</p>
                  <p className="font-semibold text-foreground">{selectedPayroll.date}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <span className="px-3 py-1 rounded-full bg-success/20 text-success text-sm">
                    {selectedPayroll.status}
                  </span>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total de Colaboradores</p>
                  <p className="font-semibold text-foreground">{selectedPayroll.employees}</p>
                </div>
              </div>

              {/* Financial Summary */}
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 rounded-lg bg-success/10 border border-success/20">
                  <p className="text-sm text-muted-foreground mb-2">Total Proventos</p>
                  <p className="text-xl font-bold font-mono text-success">
                    {formatCurrency(selectedPayroll.proventos || 0)}
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
                  <p className="text-sm text-muted-foreground mb-2">Total Descontos</p>
                  <p className="text-xl font-bold font-mono text-destructive">
                    {formatCurrency(selectedPayroll.descontos || 0)}
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <p className="text-sm text-muted-foreground mb-2">Total Líquido</p>
                  <p className="text-xl font-bold font-mono text-primary">
                    {formatCurrency(selectedPayroll.total)}
                  </p>
                </div>
              </div>

              {/* Average per Employee */}
              <div className="p-6 rounded-lg bg-gradient-to-r from-primary/20 to-accent/20 border border-primary/20">
                <p className="text-sm text-muted-foreground mb-2">Média por Colaborador</p>
                <p className="text-3xl font-bold font-mono text-foreground">
                  {formatCurrency(selectedPayroll.total / selectedPayroll.employees)}
                </p>
              </div>

              {/* Actions */}
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setIsViewModalOpen(false)}>
                  Fechar
                </Button>
                <Button onClick={() => {
                  handleDownload(selectedPayroll);
                  setIsViewModalOpen(false);
                }}>
                  <Download className="w-4 h-4 mr-2" />
                  Baixar Relatório
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
