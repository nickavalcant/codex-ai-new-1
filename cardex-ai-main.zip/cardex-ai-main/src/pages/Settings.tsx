import { Building2, Users, Shield, Bell, Database, FileText } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Header } from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

const settingsSections = [
  { id: "company", title: "Dados da Empresa", icon: Building2 },
  { id: "users", title: "Usuários", icon: Users },
  { id: "permissions", title: "Permissões", icon: Shield },
  { id: "notifications", title: "Notificações", icon: Bell },
  { id: "database", title: "Banco de Dados", icon: Database },
  { id: "documents", title: "Documentos", icon: FileText },
];

export default function Settings() {
  return (
    <MainLayout>
      <Header 
        title="Configurações" 
        subtitle="Gerencie as configurações do sistema"
      />
      
      <div className="p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Company Settings */}
          <div className="glass-card rounded-xl p-6 animate-slide-up opacity-0" style={{ animationDelay: '0ms', animationFillMode: 'forwards' }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-primary/20">
                <Building2 className="w-5 h-5 text-primary" />
              </div>
              <h2 className="text-lg font-semibold text-foreground">Dados da Empresa</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nome da Empresa</Label>
                <Input defaultValue="Empresa Exemplo LTDA" />
              </div>
              <div className="space-y-2">
                <Label>CNPJ</Label>
                <Input defaultValue="12.345.678/0001-90" />
              </div>
              <div className="space-y-2">
                <Label>Endereço</Label>
                <Input defaultValue="Av. Paulista, 1000" />
              </div>
              <div className="space-y-2">
                <Label>Cidade/Estado</Label>
                <Input defaultValue="São Paulo - SP" />
              </div>
            </div>
            
            <div className="mt-6 flex justify-end">
              <Button variant="glow">Salvar Alterações</Button>
            </div>
          </div>

          {/* Notification Settings */}
          <div className="glass-card rounded-xl p-6 animate-slide-up opacity-0" style={{ animationDelay: '100ms', animationFillMode: 'forwards' }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-accent/20">
                <Bell className="w-5 h-5 text-accent" />
              </div>
              <h2 className="text-lg font-semibold text-foreground">Notificações</h2>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between py-3 border-b border-border">
                <div>
                  <p className="font-medium text-foreground">Notificar novo holerite</p>
                  <p className="text-sm text-muted-foreground">Enviar email quando um novo holerite for gerado</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between py-3 border-b border-border">
                <div>
                  <p className="font-medium text-foreground">Lembrete de folha</p>
                  <p className="text-sm text-muted-foreground">Lembrar sobre processamento da folha mensal</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between py-3">
                <div>
                  <p className="font-medium text-foreground">Relatórios automáticos</p>
                  <p className="text-sm text-muted-foreground">Enviar relatórios mensais por email</p>
                </div>
                <Switch />
              </div>
            </div>
          </div>

          {/* Document Settings */}
          <div className="glass-card rounded-xl p-6 animate-slide-up opacity-0" style={{ animationDelay: '200ms', animationFillMode: 'forwards' }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-warning/20">
                <FileText className="w-5 h-5 text-warning" />
              </div>
              <h2 className="text-lg font-semibold text-foreground">Configurações de Documentos</h2>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Modelo de Holerite</Label>
                <Input defaultValue="Padrão v2" readOnly className="bg-secondary/30" />
              </div>
              
              <div className="flex items-center justify-between py-3 border-b border-border">
                <div>
                  <p className="font-medium text-foreground">Incluir logo no PDF</p>
                  <p className="text-sm text-muted-foreground">Adicionar logo da empresa nos holerites</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between py-3">
                <div>
                  <p className="font-medium text-foreground">Assinatura digital</p>
                  <p className="text-sm text-muted-foreground">Incluir assinatura digital nos documentos</p>
                </div>
                <Switch defaultChecked />
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
