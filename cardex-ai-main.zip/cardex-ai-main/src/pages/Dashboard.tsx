import { Users, FileText, DollarSign, TrendingUp } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Header } from "@/components/layout/Header";
import { StatCard } from "@/components/dashboard/StatCard";
import { PayrollChart } from "@/components/dashboard/PayrollChart";
import { DepartmentChart } from "@/components/dashboard/DepartmentChart";
import { RecentPayslips } from "@/components/dashboard/RecentPayslips";

export default function Dashboard() {
  return (
    <MainLayout>
      <Header 
        title="Dashboard" 
        subtitle="Visão geral do sistema de holerites"
      />
      
      <div className="p-6 space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Total Colaboradores"
            value="143"
            change="+12%"
            changeType="positive"
            icon={Users}
            iconColor="text-primary"
            delay={0}
          />
          <StatCard
            title="Holerites Gerados"
            value="286"
            change="+8%"
            changeType="positive"
            icon={FileText}
            iconColor="text-accent"
            delay={100}
          />
          <StatCard
            title="Folha Mensal"
            value="R$ 295.000"
            change="+5,4%"
            changeType="positive"
            icon={DollarSign}
            iconColor="text-warning"
            delay={200}
          />
          <StatCard
            title="Média Salarial"
            value="R$ 5.120"
            change="+2,1%"
            changeType="positive"
            icon={TrendingUp}
            iconColor="text-success"
            delay={300}
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <PayrollChart />
          </div>
          <div>
            <DepartmentChart />
          </div>
        </div>

        {/* Recent Payslips */}
        <RecentPayslips />
      </div>
    </MainLayout>
  );
}
