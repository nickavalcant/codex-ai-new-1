import { useState } from "react";
import { Search, Filter, MoreVertical, Edit, Trash2, FileText, Plus } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Header } from "@/components/layout/Header";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { EmployeeModal } from "@/components/employees/EmployeeModal";

const employees = [
  { id: 1, name: "Pedro Oliveira", cpf: "123.456.789-00", cargo: "Analista", departamento: "TI", banco: "Itaú", agencia: "5555", conta: "11111-2", salario: 4350.00 },
  { id: 2, name: "Maria Santos", cpf: "234.567.890-11", cargo: "Desenvolvedora", departamento: "TI", banco: "Bradesco", agencia: "1234", conta: "56789-0", salario: 6200.00 },
  { id: 3, name: "João Silva", cpf: "345.678.901-22", cargo: "Gerente", departamento: "Comercial", banco: "Santander", agencia: "4321", conta: "98765-4", salario: 8500.00 },
  { id: 4, name: "Ana Costa", cpf: "456.789.012-33", cargo: "Designer", departamento: "Marketing", banco: "Nubank", agencia: "0001", conta: "12345-6", salario: 5100.00 },
  { id: 5, name: "Carlos Lima", cpf: "567.890.123-44", cargo: "Contador", departamento: "Financeiro", banco: "Caixa", agencia: "2468", conta: "13579-0", salario: 5800.00 },
  { id: 6, name: "Fernanda Rocha", cpf: "678.901.234-55", cargo: "Analista RH", departamento: "RH", banco: "BB", agencia: "3579", conta: "24680-1", salario: 4800.00 },
];

export default function Employees() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<typeof employees[0] | null>(null);

  const handleAddNew = () => {
    setSelectedEmployee(null);
    setIsModalOpen(true);
  };

  const handleEdit = (employee: typeof employees[0]) => {
    setSelectedEmployee(employee);
    setIsModalOpen(true);
  };

  return (
    <MainLayout>
      <Header 
        title="Colaboradores" 
        subtitle="Gerencie os funcionários da empresa"
        action={{ label: "Novo Colaborador", onClick: handleAddNew }}
      />
      
      <div className="p-6 space-y-6">
        {/* Filters */}
        <div className="glass-card rounded-xl p-4 animate-fade-in">
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="Buscar colaborador..." className="pl-10" />
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Filtros
            </Button>
          </div>
        </div>

        {/* Table */}
        <div className="glass-card rounded-xl overflow-hidden animate-slide-up opacity-0" style={{ animationDelay: '100ms', animationFillMode: 'forwards' }}>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/30">
                  <th className="text-left py-4 px-6 text-sm font-semibold text-muted-foreground">Nome</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-muted-foreground">CPF</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-muted-foreground">Cargo</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-muted-foreground">Departamento</th>
                  <th className="text-left py-4 px-6 text-sm font-semibold text-muted-foreground">Dados Bancários</th>
                  <th className="text-right py-4 px-6 text-sm font-semibold text-muted-foreground">Salário</th>
                  <th className="text-center py-4 px-6 text-sm font-semibold text-muted-foreground">Ações</th>
                </tr>
              </thead>
              <tbody>
                {employees.map((employee) => (
                  <tr key={employee.id} className="table-row-hover border-b border-border/50">
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/50 to-accent/50 flex items-center justify-center">
                          <span className="text-sm font-semibold text-foreground">
                            {employee.name.split(' ').map(n => n[0]).join('')}
                          </span>
                        </div>
                        <span className="font-medium text-foreground">{employee.name}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6 font-mono text-sm text-muted-foreground">{employee.cpf}</td>
                    <td className="py-4 px-6 text-foreground">{employee.cargo}</td>
                    <td className="py-4 px-6">
                      <span className="px-3 py-1 rounded-full bg-secondary text-sm text-foreground">
                        {employee.departamento}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-sm text-muted-foreground">
                      <div>
                        <span className="text-foreground">{employee.banco}</span>
                        <span className="mx-1">•</span>
                        <span>Ag: {employee.agencia}</span>
                        <span className="mx-1">•</span>
                        <span>CC: {employee.conta}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6 text-right font-mono font-semibold text-foreground">
                      R$ {employee.salario.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center justify-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button className="p-2 rounded-lg hover:bg-secondary transition-colors">
                              <MoreVertical className="w-4 h-4 text-muted-foreground" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEdit(employee)}>
                              <Edit className="w-4 h-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <FileText className="w-4 h-4 mr-2" />
                              Ver Holerites
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive">
                              <Trash2 className="w-4 h-4 mr-2" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          <div className="px-6 py-4 border-t border-border flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Mostrando 1-6 de 143 colaboradores
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>Anterior</Button>
              <Button variant="outline" size="sm">Próximo</Button>
            </div>
          </div>
        </div>
      </div>

      <EmployeeModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)}
        employee={selectedEmployee}
      />
    </MainLayout>
  );
}
