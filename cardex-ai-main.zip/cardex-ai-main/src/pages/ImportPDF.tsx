import { useState, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Upload, FileText, CheckCircle, ArrowRight, Loader2, AlertCircle, RotateCcw } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Header } from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { usePayslipExtractor, ExtractedPayslipData } from "@/hooks/usePayslipExtractor";

export default function ImportPDF() {
  const navigate = useNavigate();
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [extractedData, setExtractedData] = useState<ExtractedPayslipData | null>(null);
  
  // File input ref for resetting
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { extractData, isProcessing, error, clearError } = usePayslipExtractor();

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.type === 'application/pdf') {
      // Clear previous data before setting new file
      setExtractedData(null);
      clearError();
      setFile(droppedFile);
    } else {
      toast({
        title: "Arquivo inválido",
        description: "Por favor, selecione um arquivo PDF.",
        variant: "destructive",
      });
    }
  }, [clearError]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      // Clear previous data before setting new file
      setExtractedData(null);
      clearError();
      setFile(selectedFile);
    }
  };

  const processFile = async () => {
    if (!file) return;
    
    // Clear previous extraction data
    setExtractedData(null);
    
    const data = await extractData(file);
    
    if (data) {
      setExtractedData(data);
      toast({
        title: "PDF processado com sucesso!",
        description: "Os dados foram extraídos automaticamente.",
      });
    } else {
      toast({
        title: "Erro ao processar PDF",
        description: error || "Não foi possível extrair os dados do holerite.",
        variant: "destructive",
      });
    }
  };

  const resetUpload = useCallback(() => {
    // Complete state reset
    setExtractedData(null);
    setFile(null);
    clearError();
    
    // Reset file input to allow re-selecting same file
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    
    console.log('Estado completamente resetado para novo upload');
  }, [clearError]);

  const saveAndEdit = () => {
    toast({
      title: "Holerite importado!",
      description: "Redirecionando para o editor...",
    });
    navigate('/payslips/new');
  };

  const formatCurrency = (value: number) => {
    return `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  };

  return (
    <MainLayout>
      <Header 
        title="Importar PDF" 
        subtitle="Faça upload de holerites para extração automática com IA"
      />
      
      <div className="p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Upload Area */}
          {!extractedData && (
            <div className="animate-fade-in">
              <div
                className={cn(
                  "glass-card rounded-xl p-12 border-2 border-dashed transition-all duration-300 cursor-pointer",
                  isDragging ? "border-primary bg-primary/5" : "border-border hover:border-primary/50",
                  file && "border-success bg-success/5"
                )}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => document.getElementById('file-input')?.click()}
              >
                <input
                  ref={fileInputRef}
                  id="file-input"
                  type="file"
                  accept=".pdf"
                  className="hidden"
                  onChange={handleFileSelect}
                />
                
                <div className="text-center">
                  {file ? (
                    <>
                      <div className="w-16 h-16 mx-auto rounded-full bg-success/20 flex items-center justify-center mb-4">
                        <FileText className="w-8 h-8 text-success" />
                      </div>
                      <h3 className="text-xl font-semibold text-foreground mb-2">
                        {file.name}
                      </h3>
                      <p className="text-muted-foreground mb-6">
                        {(file.size / 1024).toFixed(1)} KB • PDF
                      </p>
                      
                      {error && (
                        <div className="mb-4 p-3 rounded-lg bg-destructive/10 border border-destructive/20 flex items-center gap-2 text-destructive">
                          <AlertCircle className="w-5 h-5" />
                          <span className="text-sm">{error}</span>
                        </div>
                      )}
                      
                      <Button 
                        variant="glow" 
                        size="lg"
                        onClick={(e) => {
                          e.stopPropagation();
                          processFile();
                        }}
                        disabled={isProcessing}
                      >
                        {isProcessing ? (
                          <>
                            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                            Processando com IA...
                          </>
                        ) : (
                          <>
                            <Upload className="w-5 h-5 mr-2" />
                            Processar PDF
                          </>
                        )}
                      </Button>
                    </>
                  ) : (
                    <>
                      <div className="w-16 h-16 mx-auto rounded-full bg-primary/20 flex items-center justify-center mb-4">
                        <Upload className="w-8 h-8 text-primary" />
                      </div>
                      <h3 className="text-xl font-semibold text-foreground mb-2">
                        Arraste o PDF aqui
                      </h3>
                      <p className="text-muted-foreground mb-4">
                        ou clique para selecionar um arquivo
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Suporta arquivos PDF até 10MB
                      </p>
                    </>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Extracted Data */}
          {extractedData && (
            <div className="space-y-6 animate-slide-up">
              {/* Success Banner */}
              <div className="glass-card rounded-xl p-4 bg-success/10 border-success/20">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-6 h-6 text-success" />
                  <div>
                    <h3 className="font-semibold text-foreground">Dados extraídos com sucesso!</h3>
                    <p className="text-sm text-muted-foreground">
                      Revise os dados abaixo e faça ajustes se necessário.
                    </p>
                  </div>
                </div>
              </div>

              {/* Employee Data */}
              <div className="glass-card rounded-xl p-6">
                <h2 className="text-lg font-semibold text-foreground mb-4">Dados do Colaborador</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Nome</Label>
                    <Input value={extractedData.employee || 'Não identificado'} readOnly className="bg-secondary/30" />
                  </div>
                  <div className="space-y-2">
                    <Label>Cargo</Label>
                    <Input value={extractedData.cargo || 'Não identificado'} readOnly className="bg-secondary/30" />
                  </div>
                  <div className="space-y-2">
                    <Label>Período</Label>
                    <Input value={extractedData.period || 'Não identificado'} readOnly className="bg-secondary/30" />
                  </div>
                  <div className="space-y-2">
                    <Label>Banco</Label>
                    <Input value={extractedData.banco || 'Não identificado'} readOnly className="bg-secondary/30" />
                  </div>
                  <div className="space-y-2">
                    <Label>Agência</Label>
                    <Input value={extractedData.agencia || 'Não identificado'} readOnly className="bg-secondary/30" />
                  </div>
                  <div className="space-y-2">
                    <Label>Conta</Label>
                    <Input value={extractedData.conta || 'Não identificado'} readOnly className="bg-secondary/30" />
                  </div>
                </div>
              </div>

              {/* Financial Data */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="glass-card rounded-xl p-6">
                  <h2 className="text-lg font-semibold text-foreground mb-4">Proventos</h2>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-muted-foreground">Salário Base</span>
                      <span className="font-mono text-foreground">
                        {formatCurrency(extractedData.salarioBase)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-muted-foreground">Horas Extras</span>
                      <span className="font-mono text-foreground">
                        {formatCurrency(extractedData.horasExtras)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-muted-foreground">Adicionais</span>
                      <span className="font-mono text-foreground">
                        {formatCurrency(extractedData.adicionais)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-muted-foreground">Bônus</span>
                      <span className="font-mono text-foreground">
                        {formatCurrency(extractedData.bonus)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-muted-foreground">Comissões</span>
                      <span className="font-mono text-foreground">
                        {formatCurrency(extractedData.comissoes)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center pt-2">
                      <span className="font-medium text-foreground">Total Proventos</span>
                      <span className="font-mono font-bold text-success">
                        {formatCurrency(extractedData.totalProventos)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="glass-card rounded-xl p-6">
                  <h2 className="text-lg font-semibold text-foreground mb-4">Descontos</h2>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-muted-foreground">INSS</span>
                      <span className="font-mono text-foreground">
                        {formatCurrency(extractedData.inss)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-muted-foreground">IRRF</span>
                      <span className="font-mono text-foreground">
                        {formatCurrency(extractedData.irrf)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-muted-foreground">Faltas</span>
                      <span className="font-mono text-foreground">
                        {formatCurrency(extractedData.faltas)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-2 border-b border-border">
                      <span className="text-muted-foreground">Benefícios</span>
                      <span className="font-mono text-foreground">
                        {formatCurrency(extractedData.beneficios)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center pt-2">
                      <span className="font-medium text-foreground">Total Descontos</span>
                      <span className="font-mono font-bold text-destructive">
                        {formatCurrency(extractedData.totalDescontos)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Salary Summary */}
              <div className="glass-card rounded-xl p-6 gradient-border">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground">Salário Líquido Extraído</p>
                    <p className="text-sm text-muted-foreground">
                      {extractedData.employee || 'Funcionário'} • {extractedData.period || 'Período'}
                    </p>
                  </div>
                  <p className="font-mono font-bold text-4xl gradient-text">
                    {formatCurrency(extractedData.salarioLiquido)}
                  </p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-4">
                <Button 
                  variant="outline" 
                  onClick={resetUpload}
                >
                  Importar Outro
                </Button>
                <Button variant="glow" size="lg" onClick={saveAndEdit}>
                  Salvar e Editar
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
