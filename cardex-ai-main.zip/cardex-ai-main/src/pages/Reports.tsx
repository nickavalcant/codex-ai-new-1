import { Download, FileSpreadsheet, FileText, BarChart3, TrendingUp, Users, DollarSign } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Header } from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";

const reportTypes = [
  {
    id: "payroll-summary",
    title: "Resumo da Folha",
    description: "Visão geral da folha de pagamento mensal",
    icon: DollarSign,
    color: "text-primary",
  },
  {
    id: "employee-list",
    title: "Lista de Colaboradores",
    description: "Relatório completo de todos os funcionários",
    icon: Users,
    color: "text-accent",
  },
  {
    id: "payslip-history",
    title: "Histórico de Holerites",
    description: "Histórico completo de holerites por período",
    icon: FileText,
    color: "text-warning",
  },
  {
    id: "cost-analysis",
    title: "Análise de Custos",
    description: "Análise detalhada dos custos da folha",
    icon: TrendingUp,
    color: "text-success",
  },
  {
    id: "department-report",
    title: "Relatório por Departamento",
    description: "Custos e métricas por departamento",
    icon: BarChart3,
    color: "text-info",
  },
  {
    id: "tax-report",
    title: "Relatório de Impostos",
    description: "INSS, IRRF, FGTS e outros encargos",
    icon: FileSpreadsheet,
    color: "text-destructive",
  },
];

export default function Reports() {
  const handleExport = (format: string, reportId: string) => {
    toast({
      title: "Exportando relatório...",
      description: `O relatório será baixado em formato ${format.toUpperCase()}.`,
    });
  };

  return (
    <MainLayout>
      <Header 
        title="Relatórios" 
        subtitle="Exporte e visualize relatórios do sistema"
      />
      
      <div className="p-6 space-y-6">
        {/* Filters */}
        <div className="glass-card rounded-xl p-4 animate-fade-in">
          <div className="flex items-center gap-4 flex-wrap">
            <Select defaultValue="01-2024">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="01-2024">Janeiro 2024</SelectItem>
                <SelectItem value="12-2023">Dezembro 2023</SelectItem>
                <SelectItem value="11-2023">Novembro 2023</SelectItem>
                <SelectItem value="q4-2023">Q4 2023</SelectItem>
                <SelectItem value="2023">Ano 2023</SelectItem>
              </SelectContent>
            </Select>
            
            <Select defaultValue="all">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Departamento" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="ti">TI</SelectItem>
                <SelectItem value="rh">RH</SelectItem>
                <SelectItem value="financeiro">Financeiro</SelectItem>
                <SelectItem value="comercial">Comercial</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Report Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reportTypes.map((report, index) => (
            <div 
              key={report.id}
              className="glass-card-hover rounded-xl p-6 animate-slide-up opacity-0"
              style={{ animationDelay: `${index * 50}ms`, animationFillMode: 'forwards' }}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-xl bg-secondary ${report.color}`}>
                  <report.icon className="w-6 h-6" />
                </div>
              </div>
              
              <h3 className="text-lg font-semibold text-foreground mb-2">{report.title}</h3>
              <p className="text-sm text-muted-foreground mb-6">{report.description}</p>
              
              <div className="flex items-center gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1"
                  onClick={() => handleExport('pdf', report.id)}
                >
                  <FileText className="w-4 h-4 mr-1" />
                  PDF
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1"
                  onClick={() => handleExport('excel', report.id)}
                >
                  <FileSpreadsheet className="w-4 h-4 mr-1" />
                  Excel
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Stats */}
        <div className="glass-card rounded-xl p-6 animate-slide-up opacity-0" style={{ animationDelay: '400ms', animationFillMode: 'forwards' }}>
          <h3 className="text-lg font-semibold text-foreground mb-6">Resumo Rápido - Janeiro 2024</h3>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center p-4 rounded-xl bg-secondary/30">
              <p className="text-sm text-muted-foreground mb-1">Total Bruto</p>
              <p className="text-2xl font-bold font-mono text-foreground">R$ 385.000</p>
            </div>
            <div className="text-center p-4 rounded-xl bg-secondary/30">
              <p className="text-sm text-muted-foreground mb-1">INSS</p>
              <p className="text-2xl font-bold font-mono text-foreground">R$ 42.350</p>
            </div>
            <div className="text-center p-4 rounded-xl bg-secondary/30">
              <p className="text-sm text-muted-foreground mb-1">IRRF</p>
              <p className="text-2xl font-bold font-mono text-foreground">R$ 28.900</p>
            </div>
            <div className="text-center p-4 rounded-xl bg-secondary/30">
              <p className="text-sm text-muted-foreground mb-1">FGTS</p>
              <p className="text-2xl font-bold font-mono text-foreground">R$ 30.800</p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
