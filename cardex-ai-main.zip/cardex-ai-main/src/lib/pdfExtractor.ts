/**
 * Converts a File to base64 string for server-side processing
 * Each call creates a fresh FileReader - no caching
 */
export async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    // Create new FileReader for each file - ensures no state reuse
    const reader = new FileReader();
    
    reader.onload = () => {
      const result = reader.result as string;
      // Extract base64 data after the data URL prefix
      const base64 = result.includes(',') ? result.split(',')[1] : result;
      resolve(base64);
    };
    
    reader.onerror = () => {
      reject(new Error('Falha ao ler o arquivo PDF'));
    };
    
    reader.readAsDataURL(file);
  });
}

/**
 * Gets basic file info for logging
 */
export function getFileInfo(file: File): { name: string; size: number; type: string } {
  return {
    name: file.name,
    size: file.size,
    type: file.type,
  };
}
