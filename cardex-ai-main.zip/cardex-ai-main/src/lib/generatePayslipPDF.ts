import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export interface PayslipData {
  // Company Info
  companyName: string;
  companyAddress?: string;
  companyCNPJ?: string;
  period: string;
  
  // Employee Info
  employeeNumber?: string;
  employeeName: string;
  admissionDate?: string;
  cbo?: string;
  pisCN?: string;
  role: string;
  department?: string;
  
  // Bank Info
  bank?: string;
  agency?: string;
  account?: string;
  
  // Earnings (Vencimentos)
  earnings: Array<{
    code: string;
    description: string;
    reference?: string;
    value: number;
  }>;
  
  // Deductions (Descontos)
  deductions: Array<{
    code: string;
    description: string;
    reference?: string;
    value: number;
  }>;
  
  // Totals
  totalEarnings: number;
  totalDeductions: number;
  netSalary: number;
  
  // Fiscal Info
  baseSalary?: number;
  inssBase?: number;
  fgtsBase?: number;
  fgtsValue?: number;
  irrfBase?: number;
  irrfRange?: string;
}

export function generatePayslipPDF(data: PayslipData): void {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  let yPos = 15;

  // Helper function to add centered text
  const addCenteredText = (text: string, y: number, fontSize: number = 12, style: 'normal' | 'bold' = 'normal') => {
    doc.setFontSize(fontSize);
    doc.setFont('helvetica', style);
    const textWidth = doc.getTextWidth(text);
    doc.text(text, (pageWidth - textWidth) / 2, y);
  };

  // Helper to format currency
  const formatCurrency = (value: number): string => {
    return value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  // ========== HEADER ==========
  doc.setDrawColor(0);
  doc.setLineWidth(0.5);
  doc.rect(10, 10, pageWidth - 20, 30);
  
  addCenteredText('Demonstrativo de Pagamento de Salário', 20, 14, 'bold');
  addCenteredText(data.companyName, 28, 11, 'normal');
  
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  if (data.companyAddress) {
    addCenteredText(data.companyAddress, 34, 9);
  }
  
  // Period and CNPJ on sides
  doc.setFontSize(9);
  doc.text(`Período: ${data.period}`, 15, 38);
  if (data.companyCNPJ) {
    const cnpjText = `CNPJ: ${data.companyCNPJ}`;
    doc.text(cnpjText, pageWidth - 15 - doc.getTextWidth(cnpjText), 38);
  }

  yPos = 50;

  // ========== EMPLOYEE INFO ==========
  doc.setFillColor(230, 230, 230);
  doc.rect(10, yPos, pageWidth - 20, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('Funcionário', 15, yPos + 6);
  
  yPos += 12;

  // Employee table
  autoTable(doc, {
    startY: yPos,
    margin: { left: 10, right: 10 },
    head: [['Nro', 'Nome', 'Admissão', 'CBO', 'PIS/CN', 'Função']],
    body: [[
      data.employeeNumber || '-',
      data.employeeName,
      data.admissionDate || '-',
      data.cbo || '-',
      data.pisCN || '-',
      data.role
    ]],
    styles: { fontSize: 8, cellPadding: 2 },
    headStyles: { fillColor: [100, 100, 100], textColor: [255, 255, 255], fontStyle: 'bold' },
    theme: 'grid',
  });

  yPos = (doc as any).lastAutoTable.finalY + 10;

  // Bank info if available
  if (data.bank || data.agency || data.account) {
    doc.setFillColor(240, 240, 240);
    doc.rect(10, yPos, pageWidth - 20, 8, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('Dados Bancários', 15, yPos + 6);
    
    yPos += 12;
    
    autoTable(doc, {
      startY: yPos,
      margin: { left: 10, right: 10 },
      head: [['Banco', 'Agência', 'Conta']],
      body: [[
        data.bank || '-',
        data.agency || '-',
        data.account || '-'
      ]],
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [100, 100, 100], textColor: [255, 255, 255], fontStyle: 'bold' },
      theme: 'grid',
    });
    
    yPos = (doc as any).lastAutoTable.finalY + 10;
  }

  // ========== EARNINGS AND DEDUCTIONS ==========
  doc.setFillColor(230, 230, 230);
  doc.rect(10, yPos, pageWidth - 20, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('Vencimentos e Descontos', 15, yPos + 6);
  
  yPos += 12;

  // Combine earnings and deductions into single table
  const maxRows = Math.max(data.earnings.length, data.deductions.length);
  const tableBody: string[][] = [];
  
  for (let i = 0; i < maxRows; i++) {
    const earning = data.earnings[i];
    const deduction = data.deductions[i];
    
    tableBody.push([
      earning?.code || '',
      earning?.description || '',
      earning?.reference?.toString() || '',
      earning ? formatCurrency(earning.value) : '',
      deduction ? formatCurrency(deduction.value) : ''
    ]);
  }

  // If no items, add placeholder
  if (tableBody.length === 0) {
    tableBody.push(['', 'Sem lançamentos', '', '', '']);
  }

  autoTable(doc, {
    startY: yPos,
    margin: { left: 10, right: 10 },
    head: [['Cód', 'Descrição', 'Ref.', 'Vencimentos', 'Descontos']],
    body: tableBody,
    styles: { fontSize: 8, cellPadding: 2 },
    headStyles: { fillColor: [100, 100, 100], textColor: [255, 255, 255], fontStyle: 'bold' },
    columnStyles: {
      0: { cellWidth: 15 },
      1: { cellWidth: 80 },
      2: { cellWidth: 25 },
      3: { cellWidth: 30, halign: 'right' },
      4: { cellWidth: 30, halign: 'right' },
    },
    theme: 'grid',
  });

  yPos = (doc as any).lastAutoTable.finalY + 10;

  // ========== TOTALS ==========
  doc.setFillColor(230, 230, 230);
  doc.rect(10, yPos, pageWidth - 20, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('Totais', 15, yPos + 6);
  
  yPos += 12;

  autoTable(doc, {
    startY: yPos,
    margin: { left: 10, right: 10 },
    body: [
      ['Total Vencimentos', formatCurrency(data.totalEarnings), 'Total Descontos', formatCurrency(data.totalDeductions)],
      [{ content: 'Valor Líquido', colSpan: 2, styles: { fontStyle: 'bold', fontSize: 10 } }, { content: formatCurrency(data.netSalary), colSpan: 2, styles: { fontStyle: 'bold', fontSize: 12, halign: 'right' } }],
    ],
    styles: { fontSize: 9, cellPadding: 3 },
    theme: 'grid',
    columnStyles: {
      0: { fontStyle: 'bold' },
      1: { halign: 'right' },
      2: { fontStyle: 'bold' },
      3: { halign: 'right' },
    },
  });

  yPos = (doc as any).lastAutoTable.finalY + 10;

  // ========== FISCAL INFO ==========
  if (data.baseSalary || data.inssBase || data.fgtsBase) {
    doc.setFillColor(240, 240, 240);
    doc.rect(10, yPos, pageWidth - 20, 8, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('Informações Fiscais', 15, yPos + 6);
    
    yPos += 12;

    autoTable(doc, {
      startY: yPos,
      margin: { left: 10, right: 10 },
      head: [['Salário Base', 'Sal. Contr. INSS', 'Base Calc. FGTS', 'Valor FGTS', 'Base IRRF', 'Faixa IRRF']],
      body: [[
        data.baseSalary ? formatCurrency(data.baseSalary) : '-',
        data.inssBase ? formatCurrency(data.inssBase) : '-',
        data.fgtsBase ? formatCurrency(data.fgtsBase) : '-',
        data.fgtsValue ? formatCurrency(data.fgtsValue) : '-',
        data.irrfBase ? formatCurrency(data.irrfBase) : '-',
        data.irrfRange || '-'
      ]],
      styles: { fontSize: 7, cellPadding: 2 },
      headStyles: { fillColor: [100, 100, 100], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 7 },
      theme: 'grid',
    });

    yPos = (doc as any).lastAutoTable.finalY + 15;
  }

  // ========== SIGNATURE SECTION ==========
  doc.setFillColor(250, 250, 250);
  doc.rect(10, yPos, pageWidth - 20, 35, 'F');
  doc.rect(10, yPos, pageWidth - 20, 35);
  
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('Declaração', 15, yPos + 8);
  
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text('DECLARO TER RECEBIDO A IMPORTÂNCIA LÍQUIDA DISCRIMINADA NESTE RECIBO', 15, yPos + 16);
  
  doc.text('Data: ____/____/____', 15, yPos + 28);
  doc.text('Assinatura: _________________________________________', pageWidth / 2 - 20, yPos + 28);

  // ========== FOOTER ==========
  const footerY = doc.internal.pageSize.getHeight() - 10;
  doc.setFontSize(7);
  doc.setTextColor(128);
  addCenteredText(`Documento gerado em ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}`, footerY, 7);

  // Save the PDF
  const fileName = `holerite_${data.employeeName.replace(/\s+/g, '_')}_${data.period.replace('/', '-')}.pdf`;
  doc.save(fileName);
}

// Helper function to convert simple payslip data to PDF format
export function convertToPayslipPDFData(payslip: {
  employee: string;
  cargo: string;
  period: string;
  proventos: number;
  descontos: number;
  liquido: number;
  banco?: string;
  agencia?: string;
  conta?: string;
  salarioBase?: number;
  horasExtras?: number;
  inss?: number;
  irrf?: number;
  adicionais?: number;
  bonus?: number;
  comissoes?: number;
  faltas?: number;
  atrasos?: number;
  beneficios?: number;
}, companyName: string = 'Empresa'): PayslipData {
  const earnings: PayslipData['earnings'] = [];
  const deductions: PayslipData['deductions'] = [];
  
  // Add earnings
  if (payslip.salarioBase && payslip.salarioBase > 0) {
    earnings.push({ code: '01', description: 'Salário Base', value: payslip.salarioBase });
  }
  if (payslip.horasExtras && payslip.horasExtras > 0) {
    earnings.push({ code: '02', description: 'Horas Extras', value: payslip.horasExtras });
  }
  if (payslip.adicionais && payslip.adicionais > 0) {
    earnings.push({ code: '03', description: 'Adicionais', value: payslip.adicionais });
  }
  if (payslip.bonus && payslip.bonus > 0) {
    earnings.push({ code: '04', description: 'Bônus', value: payslip.bonus });
  }
  if (payslip.comissoes && payslip.comissoes > 0) {
    earnings.push({ code: '05', description: 'Comissões', value: payslip.comissoes });
  }
  
  // If no specific earnings, add a generic one
  if (earnings.length === 0) {
    earnings.push({ code: '01', description: 'Remuneração', value: payslip.proventos });
  }
  
  // Add deductions
  if (payslip.inss && payslip.inss > 0) {
    deductions.push({ code: '101', description: 'INSS', reference: '7,5%', value: payslip.inss });
  }
  if (payslip.irrf && payslip.irrf > 0) {
    deductions.push({ code: '102', description: 'IRRF', value: payslip.irrf });
  }
  if (payslip.faltas && payslip.faltas > 0) {
    deductions.push({ code: '103', description: 'Faltas', value: payslip.faltas });
  }
  if (payslip.atrasos && payslip.atrasos > 0) {
    deductions.push({ code: '104', description: 'Atrasos', value: payslip.atrasos });
  }
  if (payslip.beneficios && payslip.beneficios > 0) {
    deductions.push({ code: '105', description: 'Benefícios', value: payslip.beneficios });
  }
  
  // If no specific deductions, add a generic one if there are deductions
  if (deductions.length === 0 && payslip.descontos > 0) {
    deductions.push({ code: '101', description: 'Descontos', value: payslip.descontos });
  }

  return {
    companyName,
    period: payslip.period,
    employeeName: payslip.employee,
    role: payslip.cargo,
    bank: payslip.banco,
    agency: payslip.agencia,
    account: payslip.conta,
    earnings,
    deductions,
    totalEarnings: payslip.proventos,
    totalDeductions: payslip.descontos,
    netSalary: payslip.liquido,
    baseSalary: payslip.salarioBase,
    inssBase: payslip.proventos,
    fgtsBase: payslip.proventos,
    fgtsValue: payslip.proventos * 0.08,
    irrfBase: payslip.liquido,
  };
}
