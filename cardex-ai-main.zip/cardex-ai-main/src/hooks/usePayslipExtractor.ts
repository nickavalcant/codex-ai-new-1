import { useState, useCallback, useRef } from 'react';
import { fileToBase64, getFileInfo } from '@/lib/pdfExtractor';
import { supabase } from '@/integrations/supabase/client';

export interface ExtractedPayslipData {
  employee: string | null;
  cargo: string | null;
  departamento: string | null;
  banco: string | null;
  agencia: string | null;
  conta: string | null;
  period: string | null;
  dataEmissao: string | null;
  salarioBase: number;
  horasExtras: number;
  adicionais: number;
  bonus: number;
  comissoes: number;
  totalProventos: number;
  inss: number;
  irrf: number;
  faltas: number;
  atrasos: number;
  beneficios: number;
  impostos: number;
  totalDescontos: number;
  salarioLiquido: number;
}

interface UsePayslipExtractorReturn {
  extractData: (file: File) => Promise<ExtractedPayslipData | null>;
  isProcessing: boolean;
  error: string | null;
  clearError: () => void;
}

// Default empty data structure
const createEmptyData = (): ExtractedPayslipData => ({
  employee: null,
  cargo: null,
  departamento: null,
  banco: null,
  agencia: null,
  conta: null,
  period: null,
  dataEmissao: null,
  salarioBase: 0,
  horasExtras: 0,
  adicionais: 0,
  bonus: 0,
  comissoes: 0,
  totalProventos: 0,
  inss: 0,
  irrf: 0,
  faltas: 0,
  atrasos: 0,
  beneficios: 0,
  impostos: 0,
  totalDescontos: 0,
  salarioLiquido: 0,
});

export function usePayslipExtractor(): UsePayslipExtractorReturn {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Track processing to prevent duplicate requests
  const processingRef = useRef<string | null>(null);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const extractData = useCallback(async (file: File): Promise<ExtractedPayslipData | null> => {
    // Generate unique ID for this processing session
    const sessionId = `${file.name}-${file.size}-${Date.now()}`;
    
    // Prevent duplicate processing
    if (processingRef.current === sessionId) {
      console.log('Processamento duplicado detectado, ignorando...');
      return null;
    }

    // Clear ALL previous state before processing
    setError(null);
    setIsProcessing(true);
    processingRef.current = sessionId;

    const fileInfo = getFileInfo(file);
    console.log('========================================');
    console.log('INICIANDO NOVO PROCESSAMENTO DE PDF');
    console.log('Session ID:', sessionId);
    console.log('Arquivo:', fileInfo.name);
    console.log('Tamanho:', fileInfo.size, 'bytes');
    console.log('Tipo:', fileInfo.type);
    console.log('========================================');

    try {
      // Validate file type
      if (file.type !== 'application/pdf') {
        throw new Error('O arquivo deve ser um PDF');
      }

      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        throw new Error('O arquivo PDF deve ter no máximo 10MB');
      }

      // Convert file to base64 - fresh conversion each time
      console.log('Convertendo PDF para base64...');
      const pdfBase64 = await fileToBase64(file);
      console.log('Base64 gerado, tamanho:', pdfBase64.length);

      // Call edge function with fresh data
      console.log('Enviando para processamento na edge function...');
      const { data: functionData, error: functionError } = await supabase.functions.invoke(
        'process-payslip-pdf',
        {
          body: { 
            pdfBase64: pdfBase64,
            fileName: file.name
          }
        }
      );

      // Check for function errors
      if (functionError) {
        console.error('Erro na edge function:', functionError);
        throw new Error(functionError.message || 'Erro ao processar PDF');
      }

      // Check for API errors in response
      if (functionData?.error) {
        console.error('Erro retornado pela API:', functionData.error);
        throw new Error(functionData.error);
      }

      // Validate response data
      if (!functionData?.data) {
        console.error('Nenhum dado retornado pela API');
        throw new Error('Nenhum dado foi extraído do PDF');
      }

      console.log('Dados recebidos da API:', functionData.data);

      // Create fresh data object from API response - no reuse of previous data
      const extracted: ExtractedPayslipData = {
        employee: functionData.data.employee || null,
        cargo: functionData.data.cargo || null,
        departamento: functionData.data.departamento || null,
        banco: functionData.data.banco || null,
        agencia: functionData.data.agencia || null,
        conta: functionData.data.conta || null,
        period: functionData.data.period || null,
        dataEmissao: functionData.data.dataEmissao || null,
        salarioBase: parseFloat(functionData.data.salarioBase) || 0,
        horasExtras: parseFloat(functionData.data.horasExtras) || 0,
        adicionais: parseFloat(functionData.data.adicionais) || 0,
        bonus: parseFloat(functionData.data.bonus) || 0,
        comissoes: parseFloat(functionData.data.comissoes) || 0,
        totalProventos: parseFloat(functionData.data.totalProventos) || 0,
        inss: parseFloat(functionData.data.inss) || 0,
        irrf: parseFloat(functionData.data.irrf) || 0,
        faltas: parseFloat(functionData.data.faltas) || 0,
        atrasos: parseFloat(functionData.data.atrasos) || 0,
        beneficios: parseFloat(functionData.data.beneficios) || 0,
        impostos: parseFloat(functionData.data.impostos) || 0,
        totalDescontos: parseFloat(functionData.data.totalDescontos) || 0,
        salarioLiquido: parseFloat(functionData.data.salarioLiquido) || 0,
      };

      console.log('========================================');
      console.log('PROCESSAMENTO CONCLUÍDO COM SUCESSO');
      console.log('Funcionário:', extracted.employee);
      console.log('Salário Líquido:', extracted.salarioLiquido);
      console.log('========================================');

      return extracted;

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro desconhecido ao processar PDF';
      console.error('========================================');
      console.error('ERRO NO PROCESSAMENTO');
      console.error('Mensagem:', errorMessage);
      console.error('========================================');
      setError(errorMessage);
      return null;
    } finally {
      setIsProcessing(false);
      processingRef.current = null;
    }
  }, []);

  return {
    extractData,
    isProcessing,
    error,
    clearError,
  };
}
